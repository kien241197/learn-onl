@extends('layouts.user')

@section('content')
	@include('component.site-huongdan')
@endsection