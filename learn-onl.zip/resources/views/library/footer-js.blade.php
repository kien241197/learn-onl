    <script type="text/javascript" src="{{ asset('home/js/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('home/bootstrap/js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('home/slick/slick.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('home/js/function.js') }}"></script>
    <script type="text/javascript" src="{{ asset('home/js/main.js') }}"></script>