@extends('layouts.user')

@section('content')
	@include('component.site-course')
@endsection